# Changelog

## 1.0.0

- Guided setup: choose the total page count, then drop each sheet image when prompted.
- Cuts every image down the middle into two pages and restores book order.
- Two-page spreads with a page-turn animation; front cover and back cover show alone.
- Arrow keys, on-screen arrows, clicking a page, swipe on touch screens, jump dots, full screen.
- "Printed sheets" and "Pages in order" layouts.
- Opens with partially filled zines; empty sheets show as blank pages.
- Built-in sample zine.
- Single-page view for phone-sized windows, with a toggle.
