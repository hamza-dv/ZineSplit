<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="assets/logo-dark.svg">
    <img alt="ZineSplit" src="assets/logo-light.svg" width="420">
  </picture>
</p>

# ZineSplit

**Read your printed zine as a book.**

Export each printed sheet of your zine as an image, drop the images in, and ZineSplit cuts every image down the middle, puts the pages back in reading order, and shows you the zine as two-page spreads you can turn with the arrow keys.

![Setup: choose the page count and drop each sheet when prompted](docs/setup.png)

![Reader: pages 12 and 13 of a 24-page zine as an open spread](docs/reader.png)

Everything runs in your browser. Your images are never uploaded anywhere.

## Who it's for

ZineSplit is for people who lay out a zine **one landscape sheet per image, folded in half**, and want to read it back as a book before printing.

If you design this way (for example in Affinity, Illustrator, Photoshop, Canva or Figma), each sheet holds two pages side by side, and the pages are in *printing order*, not reading order. A 24-page zine is 12 sheets, where sheet 1 has the front cover on the right and the back cover on the left, sheet 2 has page 2 beside page 23, and so on. That is hard to proof by eye.

**Use case:** export each sheet as a PNG or JPEG, drop them into ZineSplit, and flip through the finished zine as two-page spreads. Check page order, facing-page layouts, and where the spreads fall before you waste paper.

It is not a general PDF reader, and it is not for zines already laid out as single pages in reading order (though a **Pages in order** layout is included for that case).

## Quick start

1. **Open it.** Double-click `index.html`. It opens in your default browser. There is nothing to install.
2. **Pick the page count.** Choose how many pages the zine has (4, 8, 12 ... 48). A 24-page zine needs 12 images.
3. **Drop each sheet when prompted.** ZineSplit asks for one image at a time, for example *"Image 3 of 12: drop the image with pages 3 and 22"*. Drop files anywhere on the page, or use **Choose image**. Dropping several files at once fills the next sheets in file-name order.
4. **Read.** Click **Read your zine**. The front cover shows alone, then you see spreads (2 | 3, 4 | 5 ...), and the back cover shows alone at the end.

Not ready with your own sheets yet? Click **See a sample zine** on the first screen.

## Controls

| Action | How |
|---|---|
| Next / previous page | Right / left arrow key, the on-screen arrows, or click the right / left page |
| Touch screens | Swipe left or right |
| Jump to the covers | Home / End |
| Jump to a spread | Click a dot under the book |
| Single page or two-page spread | The view button at the top |
| Full screen | The Full screen button, or press F |
| Change images or the page count | Edit pages |

## What your images should look like

Each image is **one printed side of a sheet**, landscape, **11 x 8.5 in**. It folds in half into two 5.5 x 8.5 in pages, and ZineSplit cuts it exactly down the middle.

For a 24-page zine, the 12 images in order are:

| Image | Left half | Right half | | Image | Left half | Right half |
|---|---|---|---|---|---|---|
| 1 | 24 (back cover) | 1 (front cover) | | 7 | 18 | 7 |
| 2 | 2 | 23 | | 8 | 8 | 17 |
| 3 | 22 | 3 | | 9 | 16 | 9 |
| 4 | 4 | 21 | | 10 | 10 | 15 |
| 5 | 20 | 5 | | 11 | 14 | 11 |
| 6 | 6 | 19 | | 12 | 12 | 13 |

Images are read in file-name order, with numbers sorted naturally (`Sheet 2` comes before `Sheet 10`). The setup screen shows which pages belong to each image, so you can check before you open the zine.

If your images already hold two consecutive pages each (1 | 2, 3 | 4 ...), choose **Pages in order** instead of **Printed sheets**.

### Exporting from your design app

Any app works as long as it can export one image per sheet side. Look for an option like "export artboards" or "export all pages", and choose PNG, JPEG or WebP.

- **Name the files so they sort in order**, for example `sheet-01.png`, `sheet-02.png`.
- **Use 150 dpi** (1650 x 1275 px per sheet). It looks sharp on screen and loads quickly. Use 300 dpi only if people will zoom in a lot.
- **Hide guide layers first.** Fold lines, crop marks or guides sitting on the center of the sheet will show as a faint edge on the cut.
- **File size:** WebP is usually the smallest, then JPEG, then PNG. PNG is the best choice for flat color and crisp text.

## FAQ

**The pages look out of order.**
Check the file names. Files are sorted by name, so `sheet-1`, `sheet-2` ... `sheet-12` works, and so does `sheet-01` ... `sheet-12`. Use **Edit pages** and click a sheet to replace any image that landed in the wrong slot.

**There is a thin line down the middle of my pages.**
A fold line or guide was included in the export. Hide that layer and export again.

**It says my images are portrait.**
ZineSplit expects landscape images that split into two pages. A portrait image is one single page. Export each printed sheet side as a landscape image.

**Can I open it before every sheet is added?**
Yes. Click **Read what I have**. Missing sheets appear as blank pages.

**Does it work offline?**
Yes. The only thing it loads from the internet is its fonts, and it falls back to your system fonts without them.

**Is my artwork uploaded anywhere?**
No. Images are read and displayed locally in your browser tab. Close the tab and they are gone.

**It is slow on my phone.**
Large images take memory because the browser unpacks each one into raw pixels. Export at 150 dpi, or fewer pixels, for phones and older computers.

## How it works

ZineSplit does not edit your images. Each page is a box showing one half of a sheet image. A page's position in the book decides which half of which image it shows, using the standard folded-booklet order (for an N-page zine: front of sheet k is N-2k | 2k+1, back of sheet k is 2k+2 | N-2k-1). The page turn is a CSS 3D rotation. The whole app is a single file, `index.html`, with no build step and no dependencies.

## Browser support

Current versions of Chrome, Edge, Firefox and Safari, on desktop and phones.

## Contributing

Issues and pull requests are welcome. There is no build step: edit `index.html`, open it in a browser, and test with the built-in sample zine.

Ideas that would be useful:

- Open a single PDF and treat each page as a sheet
- Export the finished reading-order pages as separate images
- Right-to-left reading order

## License

MIT. See [LICENSE](LICENSE).
